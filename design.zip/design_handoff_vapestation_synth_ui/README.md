# Handoff: VapeStation Synth UI (Rainfall restyle)

## Overview
A restyle of the VapeStation graintable-synth plugin UI in the Rainfall design system: dark slate canvas, flat gray-800 panels with subtle depth, Roboto, blue primary accent, per-source colored modulation. Static visual design — no audio engine, no interaction logic was specified beyond what's described here.

## About the Design Files
The file in this bundle (`VapeStation Rainfall.dc.html`) is a **design reference created in HTML** — a mockup showing intended look, not production code. **The source/target for this project is NOT HTML** (it is a synth plugin UI), so the bitmap screenshots in `screenshots/` are the primary reference; the HTML is a secondary, inspectable source of exact values. Recreate this design in the target environment (JUCE, iPlug2, or whatever the plugin framework is) using its native drawing/layout primitives.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and shadows are final. Recreate pixel-perfectly.

## Screenshots (`screenshots/`)
- `01-vapestation.png` — full-panel overview (scaled to fit; use for layout/proportions)
- `02`–`03` — top row at 100%: header, Graintable, OSC (02 = left, 03 = right incl. Filter)
- `04`–`05` — envelope/LFO row at 100% (left / right)
- `06`–`07` — Matrix + keyboard at 100% (left / right)

## Layout
Fixed-width panel, 1240px content width, 24px outer padding, 12px gap between all panels. Vertical stack:
1. **Header band** (full width)
2. **Row 1**: Graintable (360px) · OSC (flexible) · Filter (250px)
3. **Row 2**: ENV 1–AMP · ENV 2 · ENV 3 · LFO 1 · LFO 2 (equal flex; LFOs slightly wider, flex 1.1)
4. **Matrix** (full width)
5. **Keyboard** (full width, 5 octaves C2–C6)

### Panel (shared style)
- Background `#1f2937`, 1px border `#374151`, radius 8px
- Depth: `box-shadow: 0 1px 3px rgba(0,0,0,.28), 0 6px 16px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.05)`
- Padding 12–14px vertical, 14–16px horizontal
- Section title: 11px, weight 600, letter-spacing 0.1em, uppercase, `#9ca3af`

## Design Tokens (Rainfall)
Colors:
- App canvas: `#475569` (slate-600)
- Panel surface / nav: `#1f2937` (gray-800)
- Recessed wells (graintable display, keyboard bed, knob recess, slider tracks): `#111827`
- Input fill: `#374151`; input border: `#4b5563`
- Text: body `#d1d5db`, muted `#9ca3af`, faint `#6b7280`, strong `#ffffff`
- Primary/value accent: `#4aa5ff` (brand cloud blue) — knob arcs (Filter, Gain), waveform, position slider fill
- Mod source colors (used consistently on chips, arcs, dots, matrix rows):
  - ENV1 `#60a5fa` (blue-400)
  - ENV2 `#34d399` (emerald)
  - ENV3 `#f87171` (red-400)
  - LFO1 `#c4b5fd` (purple-300)
  - LFO2 `#e6f3ff` (ice / cloud-light)
- Destructive (matrix row remove icon): `#f87171` stroke, circled-X outline icon

Typography: Roboto everywhere. 11px labels/titles, 12–13px controls, 22px weight-900 wordmark. Value readouts in monospace (ui-monospace/Menlo), 12px.

Radii: 8px panels/inputs/selects, 4px buttons & value boxes, 9999px pills/knobs/thumbs.

Recessed elements get inset shadows: `inset 0 1px 2px rgba(0,0,0,.3)` (inputs/selects), `inset 0 2px 6px rgba(0,0,0,.45)` (wells), `inset 0 1px 2px rgba(0,0,0,.5)` (slider tracks).

## Components

### Knob (shared)
Drawn in a 56×56 coordinate space, scaled per context (OSC 56px, Filter 72px, LFO Rate 62px, envelope 50px, header Gain 44px):
- Recess disc: r=26, fill `#111827`
- Body cap: r=16, fill `#374151`, 1px stroke `#4b5563`
- Track ring: r=23, stroke `#374151`, width 3, 270° sweep starting at 7:30 (i.e. rotated 135° from 3 o'clock), round caps
- Pointer: white 2px line from center to r≈13, rotated −135°…+135° across the value range
- Label below: 11px `#9ca3af`

**Value display, two variants:**
- **Non-OSC knobs (Filter, ENVs, LFO Rate, Gain):** filled value arc on the track ring, from sweep start to current value. Arc color = `#4aa5ff` for Filter/Gain; **the mod source's chip color for ENV and LFO knobs** (ENV1 blue, ENV2 emerald, ENV3 red, LFO1 purple, LFO2 ice).
- **OSC knobs:** no value arc (it conflicted with mod arcs). Instead a white dot (r=3) on the track ring at the value angle, plus the pointer.

**Modulation arcs (OSC knobs that are modulated):** colored arcs starting at the value dot and sweeping clockwise, length proportional to the matrix amount (amount × 270°, min 6°). First mod at r=23 (on the track, width 3), second mod at r=26.5 (outside, width 2). Colors = mod source color. Modulated in this mock: Position (ENV2 0.39, LFO1 0.25), Pitch Rnd (LFO2 ~0), Shape (LFO2 0.35). Small source-colored dots (7px) also sit next to the knob label.

### Header
- Wordmark: "VAPE" in `#4aa5ff` + " STATION" in white, 22px, weight 900, slight letter-spacing
- Subtitle: 11px `#9ca3af` — "graintable prototype — drag a coloured chip onto any knob"
- Right side: INIT ghost button (1px `#4b5563` border, 12px/600 text, 4px radius), "TABLE" label + select ("Bells"), Gain knob

### Select / dropdown
`#374151` fill, 1px `#4b5563` border, 8px radius, inset shadow, white 12–13px text, chevron-down icon (24×24 viewBox, stroke `#9ca3af`, width 2, round caps).

### Graintable
Recessed `#111827` display with a 2px `#4aa5ff` waveform line. Below: position slider — 4px `#111827` track (inset shadow), `#4aa5ff` fill from left, 14px white round thumb with 1px `#4b5563` border and drop shadow. Thumb at 32%.

### Chips (mod source pills)
Pill: `#374151` fill, radius 9999px, padding 2px 9px, 10px/600 text in the source color, with a 6px dot of the same color. Used in panel headers (ENV1/ENV2/ENV3/LFO1/LFO2) and matrix rows. Gray variants (text `#9ca3af`) for VEL / WHEEL / KEY in the matrix header. Intended interaction (not implemented): chips are draggable onto any knob to create a modulation route.

### Envelope panels (×3)
Header row: title ("ENV 1 – AMP", "ENV 2", "ENV 3") + source chip. 2×2 grid of knobs: Attack, Decay, Sustain, Release. Arc color = panel's source color.

### LFO panels (×2)
Header: title + chip. Centered Rate knob (arc in source color), then two stacked selects: LFO1 = Retrig / Triangle; LFO2 = Global / Sine.

### Matrix
Header: "MATRIX" + muted "sorted by source" note, VEL/WHEEL/KEY pills right-aligned. Rows in a **2-column grid** (gap 12px × 32px), **sorted by mod source**:
- ENV2 → Position, +0.39
- LFO1 → Position, +0.25
- LFO2 → Pitch Rnd, −0.00
- LFO2 → Shape, +0.35

Row anatomy (flex, 10px gap): source chip (44px) · chevron-right icon · destination label (12px, 66px) · **bipolar slider** (flex) · value box · remove icon.
- Bipolar slider: 4px `#111827` track, **2×12px center tick `#6b7280` marking the zero point**, fill in source color from center toward the thumb, 14px white thumb at 50% + value×50%.
- Value box: `#374151` fill, `#4b5563` border, 4px radius, monospace 12px white, right-aligned, signed 2-decimal.
- Remove: 18px circled-X outline, stroke `#f87171`, width 1.5.

### Keyboard
Recessed `#111827` bed (8px padding, inset shadow). 5 octaves; per octave 7 white keys (`#f9fafb`, 1px `#1f2937` border, 96px tall, 3px bottom radius, `inset 0 -4px 0 rgba(0,0,0,.12)`) with octave label (10px `#6b7280`) on each C; 5 black keys (`#1f2937`, 58px tall, 9% octave width, drop shadow) at 14.3 / 28.6 / 57.1 / 71.4 / 85.7% of the octave.

## Interactions & Behavior (intended, not implemented)
- Knobs: drag to change value; modulated knobs show live mod arcs around the value dot
- Chips: drag a source chip onto a knob → creates a matrix row
- Matrix: sliders set bipolar amount (center = 0), value boxes accept typed values, circled-X removes the route; rows stay sorted by source
- Selects: standard dropdowns; INIT resets the patch; TABLE picks the graintable
- Keyboard: plays notes
- Rainfall idiom: hover states are instant (no transitions); no animation anywhere

## State Management
Per-knob normalized value (0–1, bipolar where noted); mod routes as {source, destination, amount ∈ [−1, 1]}; selected filter type, LFO modes/shapes, current graintable + scrub position.

## Assets
None required — all visuals are flat color + simple vector shapes (knob rings, chevrons, circled-X). Waveform is rendered from the loaded table. Icons follow Flowbite/Heroicons outline style (24×24, stroke 1.5–2, round caps).

## Files
- `VapeStation Rainfall.dc.html` — HTML design reference (inline styles carry all exact values)
- `screenshots/01…07-vapestation.png` — bitmap references (01 = overview, 02–07 = 100% crops)
